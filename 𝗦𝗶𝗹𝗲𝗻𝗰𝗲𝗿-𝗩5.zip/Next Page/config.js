global.owner = ['254104245659'] // owner number
global.connect = true 
global.url = "https://t.me/tennormodzcoder"
global.url2 = "https://t.me/tennormodzcoder"
global.packname = "Putrazy"
global.author = "Putrazy"

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})